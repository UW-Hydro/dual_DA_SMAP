#!/bin/bash -u

for BASIN in $(sed -r 's/#.*//g' setupautocal_filelist) ; do

  rm -Rf $BASIN 2> /dev/null
  mkdir -p $BASIN $BASIN/flow $BASIN/runs

  sed -r 's/(BASIN=).*/\1'"$BASIN"'/g' .BASIN_TEMPLATE/basin.conf > $BASIN/basin.conf

  cp .BASIN_TEMPLATE/param_limits.TEMPLATE.txt $BASIN/param_limits.$BASIN.txt

done
